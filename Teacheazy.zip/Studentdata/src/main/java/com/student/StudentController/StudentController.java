package com.student.StudentController;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.student.Entity.Student;
import com.student.StudentService.StudentService;

/**
 * Controller for managing Student API endpoints.
 */
@RestController
@RequestMapping("/api/students")
public class StudentController {
    private final StudentService studentService;

    /**
     * Constructor-based dependency injection for StudentService.
     * @param studentService the service layer handling business logic for Students
     */
    public StudentController(StudentService studentService) {
        this.studentService = studentService;
    }

    /**
     * Create a new Student.
     * @param student the student details
     * @return the created student
     */
    @PostMapping
    public Student createStudent(@RequestBody Student student) {
        return studentService.createStudent(student);
    }

    /**
     * Get all Students.
     * @return a list of all students
     */
    @GetMapping
    public List<Student> getAllStudents() {
        return studentService.getAllStudents();
    }
}