package com.student.SubjectController;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.student.Entity.Subject;
import com.student.SubjectService.SubjectService;

/**
 * Controller for managing Subject API endpoints.
 */
@RestController
@RequestMapping("/api/subjects")
public class SubjectController {

    private final SubjectService subjectService;

    /**
     * Constructor-based dependency injection for SubjectService.
     * @param subjectService the service layer handling business logic for Subjects
     */
    public SubjectController(SubjectService subjectService) {
        this.subjectService = subjectService;
    }

    /**
     * Create a new Subject.
     * @param subject the subject details
     * @return the created subject
     */
    @PostMapping
    public Subject createSubject(@RequestBody Subject subject) {
        return subjectService.createSubject(subject);
    }

    /**
     * Get all Subjects.
     * @return a list of all subjects
     */
    @GetMapping
    public List<Subject> getAllSubjects() {
        return subjectService.getAllSubjects();
    }
}